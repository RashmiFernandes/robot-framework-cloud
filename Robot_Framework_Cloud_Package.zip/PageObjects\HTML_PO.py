loc_HTML_AvailableObjects =    "xpath=//ul[@id='availableObjectsList']"
loc_HTML_LogOff=    "xpath=//a[contains(text(),'Log Off')]"
loc_HTML_Username = "xpath = //input[@id='UserName']"
loc_HTML_Password = "xpath = //input[@id='Password']"
loc_HTML_Login =    "id=submit-button"
loc_HTML_ApplicationDropdown = "xpath = //select[@id='HtmlEditorInstance']"

